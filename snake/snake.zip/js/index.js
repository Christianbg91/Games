window.onload = function () {
    new Menu()
};